Scriptname SoulTwisterQuestSCRIPT extends ReferenceAlias  

GlobalVariable Property GameDaysPassed Auto
Quest Property DA15 Auto
Message Property YetLateThanksMessage Auto
Spell Property Empirica Auto
Spell Property Diblohorube Auto
Spell Property BoundSoulTwister Auto

float YetLateThanksAgain = -1.0

Event OnInit()
    RegisterForUpdateGameTime(0.5)
EndEvent

Event OnUpdateGameTime()
    If DA15.GetStage() >= 200
        if YetLateThanksAgain < 0
            YetLateThanksAgain = GameDaysPassed.GetValue() + 1.0
        elseif GameDaysPassed.GetValue() > YetLateThanksAgain
            YetLateThanksMessage.Show()
            Game.GetPlayer().AddSpell(Empirica)
            Game.GetPlayer().AddSpell(Diblohorube)
            Game.GetPlayer().AddSpell(BoundSoulTwister)
            UnregisterForUpdateGameTime()
            GetOwningQuest().Stop()
        endif
    endif
EndEvent