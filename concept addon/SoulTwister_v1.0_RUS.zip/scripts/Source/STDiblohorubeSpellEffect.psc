Scriptname STDiblohorubeSpellEffect extends ActiveMagicEffect  

FormList Property STUpgradeablePotions Auto

Spell Property STDiblohorube Auto

EffectShader Property SuccessVisualisationShader Auto
Sound Property NothingHappened Auto
Sound Property PurifySuccess Auto

Event OnEffectStart(Actor akTarget, Actor akCaster)
    Actor Player = Game.GetPlayer()

    Int UpgrPotionsLength = STUpgradeablePotions.GetSize()
    Int i = 0
    Int ButtonPressed = -1

    While i < UpgrPotionsLength
        Form IterPotion = STUpgradeablePotions.GetAt(i)
        String PotionType
        String PotionName
        String PotionPurifiedName
        If Player.GetItemCount(IterPotion) > 2
            If (i != 5) && (i != 11) && (i != 17) && (i != 19) && (i != 21) && (i != 23) && (i != 25) && (i != 27) && (i != 29)
                Form PotionPurified = STUpgradeablePotions.GetAt(i + 1)
;                Debug.MessageBox("����� ��������� 3 " + PotionName + " ����� " + PotionType + " � ���� " + PotionPurifiedName)
;                ButtonPressed = STPurifyConfirmation.Show()
                ButtonPressed = ((Game.GetFormFromFile(0x00060000 + i, "SOULTWISTER.ESM")) as Message).Show()
                If ButtonPressed == 0
                    Player.RemoveItem(IterPotion, 3, true)
                    Player.AddItem(PotionPurified, 1, false)
                    PurifySuccess.Play(Player)
                    SuccessVisualisationShader.Play(Player, 2.5)
                    i = UpgrPotionsLength
                EndIf
            EndIf
        EndIf
        i += 1
    EndWhile
    if ButtonPressed == -1
;        Debug.Notification("������ ���������� ���� �����������")
        ((Game.GetFormFromFile(0x00060011 + i, "SOULTWISTER.ESM")) as Message).Show()
    endif
    if ButtonPressed != 0
        NothingHappened.Play(Player)
    endif
    Player.DispelSpell(STDiblohorube)
EndEvent