Scriptname SoulTwisterScriptMagicEffect extends ActiveMagicEffect

SoulGem Property SoulGemPettyFilled Auto
SoulGem Property SoulGemLesserFilled Auto
SoulGem Property SoulGemCommonFilled Auto
SoulGem Property SoulGemGreaterFilled Auto
SoulGem Property SoulGemGrandFilled Auto
SoulGem Property SoulGemBlackFilled Auto
SoulGem Property SoulGemPetty Auto
SoulGem Property SoulGemLesser Auto
SoulGem Property SoulGemCommon Auto
SoulGem Property SoulGemGreater Auto
SoulGem Property SoulGemGrand Auto
SoulGem Property SoulGemBlack Auto
;SoulGem Property DA01SoulGemAzurasStar Auto
SoulGem Property DA01SoulGemBlackStar Auto 

Perk Property Enchanter00 Auto
Perk Property Enchanter20 Auto
Perk Property Enchanter40 Auto
Perk Property Enchanter60 Auto
Perk Property Enchanter80 Auto
Perk Property SoulSqueezer Auto
Perk Property InsightfulEnchanter Auto
Perk Property FireEnchanter Auto
Perk Property SoulSiphon Auto
Perk Property CorpusEnchanter Auto
Perk Property FrostEnchanter Auto
Perk Property StormEnchanter Auto
Perk Property ExtraEffect Auto

Weapon Property SoulTwister Auto
Spell Property BoundSoulTwister Auto
MiscObject Property Gold001 Auto
Sound Property SoulRevesselization Auto
Sound Property JustThanks Auto
VisualEffect Property SuccessSmoke Auto
EffectShader Property SuccessVisualisationShader Auto

Actor Player
bool SkipFinish
bool Left
float StartEnchantingAV
float STCharge
int PettyCount
int PettyFilledCount
int LesserCount
int LesserFilledCount
int CommonCount
int CommonFilledCount
int GreaterCount
int GreaterFilledCount
int GrandCount
int GrandFilledCount
int InitialEnchPerksCount = 0

Event OnEffectStart(Actor akTarget, Actor akCaster)
    SkipFinish = false

    Player = Game.GetPlayer()

    StartEnchantingAV = Player.GetBaseActorValue("Enchanting")

    if Player.GetItemCount(SoulTwister) > 0
        SkipFinish = true
        Player.Kill()
        Player.DispelSpell(BoundSoulTwister)
        return
    elseif Player.GetItemCount(DA01SoulGemBlackStar) > 0
        SkipFinish = true
;        Debug.Notification("���������� �� ������ ������!")
        ((Game.GetFormFromFile(0x00070001, "SOULTWISTER.ESM")) as Message).Show()
        Player.DispelSpell(BoundSoulTwister)
        return
    elseif ((Player.GetItemCount(SoulGemBlack) > 0) || (Player.GetItemCount(SoulGemBlackFilled) > 0))
        SkipFinish = true
;        Debug.Notification("���������� �� ������ ������ ���!")
        ((Game.GetFormFromFile(0x00070002, "SOULTWISTER.ESM")) as Message).Show()
        Player.DispelSpell(BoundSoulTwister)
        return
    endif

    RegisterForSingleUpdate(3.5)

    Player.AddItem(SoulTwister, 1, true)

    Player.EquipItem(SoulTwister, false, true)

    PettyCount               = Player.GetItemCount(SoulGemPetty)
    PettyFilledCount       = Player.GetItemCount(SoulGemPettyFilled)
    LesserCount             = Player.GetItemCount(SoulGemLesser)
    LesserFilledCount     = Player.GetItemCount(SoulGemLesserFilled)
    CommonCount          = Player.GetItemCount(SoulGemCommon)
    CommonFilledCount  = Player.GetItemCount(SoulGemCommonFilled)
    GreaterCount           = Player.GetItemCount(SoulGemGreater)
    GreaterFilledCount   = Player.GetItemCount(SoulGemGreaterFilled)
    GrandCount              = Player.GetItemCount(SoulGemGrand)
    GrandFilledCount      = Player.GetItemCount(SoulGemGrandFilled)

    if Player.GetEquippedWeapon(1) == SoulTwister
        Left = true
;    elseif Player.GetEquippedWeapon(0) == SoulTwister
    else
        Left = false
    endif

    if Left
        STCharge = Player.GetActorValue("LeftItemCharge")
        Player.DamageActorValue("LeftItemCharge", STCharge)
    else
        STCharge = Player.GetActorValue("RightItemCharge")
        Player.DamageActorValue("RightItemCharge", STCharge)
    endif

    if Player.HasPerk(Enchanter00)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(Enchanter20)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(Enchanter40)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(Enchanter60)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(Enchanter80)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(SoulSqueezer)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(InsightfulEnchanter)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(FireEnchanter)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(SoulSiphon)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(CorpusEnchanter)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(FrostEnchanter)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(StormEnchanter)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif
    if Player.HasPerk(ExtraEffect)
        InitialEnchPerksCount = InitialEnchPerksCount + 1
    endif

    Player.SetActorValue("Enchanting", 100.0)

EndEvent

; Petty 250
; Lesser 500
; Common 1000
; Greater 2000
; Grand 3000

Event OnUpdate()
    int EffEndEnchPerksCount
    int SGReturn = 0
    int SGUsedQuantity = 0
    int SGUsedType
    float PerkSS
;    String SGUsedType
;    if !SkipFinish
        PettyCount = PettyCount - Player.GetItemCount(SoulGemPetty)
        LesserCount = LesserCount - Player.GetItemCount(SoulGemLesser)
        CommonCount = CommonCount - Player.GetItemCount(SoulGemCommon)
        GreaterCount = GreaterCount - Player.GetItemCount(SoulGemGreater)
        GrandCount = GrandCount - Player.GetItemCount(SoulGemGrand)
        PettyFilledCount = PettyFilledCount - Player.GetItemCount(SoulGemPettyFilled)
        LesserFilledCount = LesserFilledCount - Player.GetItemCount(SoulGemLesserFilled)
        CommonFilledCount = CommonFilledCount - Player.GetItemCount(SoulGemCommonFilled)
        GreaterFilledCount = GreaterFilledCount - Player.GetItemCount(SoulGemGreaterFilled)
        GrandFilledCount = GrandFilledCount - Player.GetItemCount(SoulGemGrandFilled)

;        SGUsedType = PettyCount + 2*LesserCount + 3*CommonCount + 4*GreaterCount + 5*GrandCount + 100*(PettyFilledCount + LesserFilledCount + CommonFilledCount + GreaterFilledCount + GrandFilledCount)

        SGUsedQuantity = PettyCount + LesserCount + CommonCount + GreaterCount + GrandCount + PettyFilledCount + LesserFilledCount + CommonFilledCount + GreaterFilledCount + GrandFilledCount

        if ((Player.GetItemCount(DA01SoulGemBlackStar) > 0) || (Player.GetItemCount(SoulGemBlack) > 0) || (Player.GetItemCount(SoulGemBlackFilled) > 0) || (Player.GetItemCount(SoulTwister) != 1) || (SGUsedQuantity < 0) || (SGUsedQuantity > 1))
            SkipFinish = true
            Player.Kill()
            Player.DispelSpell(BoundSoulTwister)
            return
        endif

        if Player.HasPerk(Enchanter00)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(Enchanter20)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(Enchanter40)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(Enchanter60)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(Enchanter80)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(SoulSqueezer)
            EffEndEnchPerksCount += 1
            PerkSS = 250.0
        else
            PerkSS = 0
        endif
        if Player.HasPerk(InsightfulEnchanter)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(FireEnchanter)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(SoulSiphon)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(CorpusEnchanter)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(FrostEnchanter)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(StormEnchanter)
            EffEndEnchPerksCount += 1
        endif
        if Player.HasPerk(ExtraEffect)
            EffEndEnchPerksCount += 1
        endif

        if ((EffEndEnchPerksCount != InitialEnchPerksCount) || (Player.GetBaseActorValue("Enchanting") < 100))
            SkipFinish = true
            Player.Kill()
            Player.DispelSpell(BoundSoulTwister)
            return
        endif

        if Left
            STCharge = Player.GetActorValue("LeftItemCharge")
        else
            STCharge = Player.GetActorValue("RightItemCharge")
        endif
;        Debug.Notification("�����: " + STCharge)

        if STCharge < 5
            SkipFinish = true
;            Debug.Notification("���...")
            ((Game.GetFormFromFile(0x00070000, "SOULTWISTER.ESM")) as Message).Show()
            Player.DispelSpell(BoundSoulTwister)
        else
            if SGUsedQuantity < 1
                SkipFinish = true
                Player.Kill()
                Player.DispelSpell(BoundSoulTwister)
                return
            endif
            STCharge = STCharge - PerkSS
            if ((STCharge > 245) && (STCharge < 255))
                if ((PettyFilledCount == 1) || ((Player.GetItemCount(SoulGemPetty) == 0) && (PettyCount == 0)) || (Player.GetGoldAmount() < 30))
                    SGReturn = -1
                else
                    SGReturn = 1
                    Player.RemoveItem(Gold001, 30, true)
                    if PettyCount == 1
                        PettyCount = 0
                    else
                        Player.RemoveItem(SoulGemPetty, 1, true)
                    endif
                    Player.AddItem(SoulGemPettyFilled, 1, true)
;                    Debug.Notification("���� ������������ � ��������� ����� ���")
;                    SGUsedType = "���������"
                    SGUsedType = 0
                endif
            elseif ((STCharge > 495) && (STCharge < 505))
                if ((LesserFilledCount == 1) || ((Player.GetItemCount(SoulGemLesser) == 0) && (LesserCount == 0)) || (Player.GetGoldAmount() < 55))
                    SGReturn = -1
                else
                    SGReturn = 1
                    Player.RemoveItem(Gold001, 55, true)
                    if LesserCount == 1
                        LesserCount = 0
                    else
                        Player.RemoveItem(SoulGemLesser, 1, true)
                    endif
                    Player.AddItem(SoulGemLesserFilled, 1, true)
;                    Debug.Notification("���� ������������ � ��������� ����� ���")
;                    SGUsedType = "���������"
                    SGUsedType = 1
                endif
            elseif ((STCharge > 995) && (STCharge < 1005))
                if ((CommonFilledCount == 1) || ((Player.GetItemCount(SoulGemCommon) == 0) && (CommonCount == 0)) || (Player.GetGoldAmount() < 100))
                    SGReturn = -1
                else
                    SGReturn = 1
                    Player.RemoveItem(Gold001, 100, true)
                    if CommonCount == 1
                        CommonCount = 0
                    else
                        Player.RemoveItem(SoulGemCommon, 1, true)
                    endif
                    Player.AddItem(SoulGemCommonFilled, 1, true)
;                    Debug.Notification("���� ������������ � ������� ����� ���")
;                    SGUsedType = "�������"
                    SGUsedType = 2
                endif
            elseif ((STCharge > 1995) && (STCharge < 2005))
                if ((GreaterFilledCount == 1) || ((Player.GetItemCount(SoulGemGreater) == 0) && (GreaterCount == 0)) || (Player.GetGoldAmount() < 250))
                    SGReturn = -1
                else
                    SGReturn = 1
                    Player.RemoveItem(Gold001, 250, true)
                    if GreaterCount == 1
                        GreaterCount = 0
                    else
                        Player.RemoveItem(SoulGemGreater, 1, true)
                    endif
                    Player.AddItem(SoulGemGreaterFilled, 1, true)
;                    Debug.Notification("���� ������������ � ������� ����� ���")
;                    SGUsedType = "�������"
                    SGUsedType = 3
                endif
            elseif ((STCharge > 2995) && (STCharge < 3005))
                if ((GrandFilledCount == 1) || ((Player.GetItemCount(SoulGemGrand) == 0) && (GrandCount == 0)) || (Player.GetGoldAmount() < 300))
                    SGReturn = -1
                else
                    SGReturn = 1
                    Player.RemoveItem(Gold001, 300, true)
                    if GrandCount == 1
                        GrandCount = 0
                    else
                        Player.RemoveItem(SoulGemGrand, 1, true)
                    endif
                    Player.AddItem(SoulGemGrandFilled, 1, true)
;                    Debug.Notification("���� ������������ � ������� ����� ���")
;                    SGUsedType = "�������"
                    SGUsedType = 4
                endif
            else
                SGReturn = -1
            endif
        endif

        if SGReturn == -1
            SkipFinish = true
;            Debug.Notification("������� �� ����")
            ((Game.GetFormFromFile(0x00070003, "SOULTWISTER.ESM")) as Message).Show()
            JustThanks.Play(Player)
        elseif SGReturn == 1
            if GrandCount == 1
                Player.AddItem(SoulGemGrand, 1, true)
            elseif GreaterCount == 1
                Player.AddItem(SoulGemGreater, 1, true)
            elseif CommonCount == 1
                Player.AddItem(SoulGemCommon, 1, true)
            elseif LesserCount == 1
                Player.AddItem(SoulGemLesser, 1, true)
            elseif PettyCount == 1
                Player.AddItem(SoulGemPetty, 1, true)
            endif
;            Debug.Notification("���� ������������ � "+ SGUsedType + " ����� ���")
            ((Game.GetFormFromFile(0x00070004 + SGUsedType, "SOULTWISTER.ESM")) as Message).Show()
            SoulRevesselization.Play(Player)
            SuccessSmoke.Play(Player, 1.0)
        endif

        Player.UnEquipItem(SoulTwister, false, true)
        Player.RemoveItem(SoulTwister, 1, true)
        if Player.GetEquippedSpell(0) != BoundSoulTwister
            Player.EquipSpell(BoundSoulTwister, 1)
        endif
;    endif
EndEvent

Event OnEffectFinish(Actor akTarget, Actor akCaster)
    if !SkipFinish
        SuccessVisualisationShader.Play(Player, 2.5)
    endif

Player.SetActorValue("Enchanting", StartEnchantingAV)

EndEvent