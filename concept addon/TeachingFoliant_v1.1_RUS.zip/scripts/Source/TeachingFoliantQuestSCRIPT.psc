Scriptname TeachingFoliantQuestSCRIPT extends ReferenceAlias

MiscObject Property RuinedBook Auto
MiscObject Property RuinedBook02 Auto
Book Property TeachingFoliant Auto ;
Message Property TeachFolInitialMSG Auto

Event OnItemAdded(Form akBaseItem, Int aiItemCount, ObjectReference akItemReference, ObjectReference akSourceContainer)
    Actor PlayerRef = Game.GetPlayer()
    
    if ((akBaseItem == RuinedBook) || (akBaseItem == RuinedBook02))
        PlayerRef.RemoveItem(akBaseItem, 1, true) ;
        PlayerRef.AddItem(TeachingFoliant, 1, false) ;
        TeachFolInitialMSG.Show()
        GetOwningQuest().Stop()
    endif
EndEvent
